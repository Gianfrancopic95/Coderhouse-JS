// bundle.js - sin módulos (compat file://), con donut chart
const KEYS = { CONFIG:'sim_config', GASTOS:'sim_gastos' };
const storage = {
  saveConfig(c){ localStorage.setItem(KEYS.CONFIG, JSON.stringify(c)); },
  loadConfig(){ try{ return JSON.parse(localStorage.getItem(KEYS.CONFIG)) || {presupuesto:0,meta:0}; }catch(_){ return {presupuesto:0,meta:0}; } },
  saveGastos(g){ localStorage.setItem(KEYS.GASTOS, JSON.stringify(g)); },
  loadGastos(){ try{ return JSON.parse(localStorage.getItem(KEYS.GASTOS)) || []; }catch(_){ return []; } }
};

function fmtMoney(n){ if(isNaN(n)) return '$0'; return Number(n).toLocaleString('es-AR',{style:'currency',currency:'ARS',maximumFractionDigits:2}); }
function fmtDate(iso){ const d=new Date(iso); return isNaN(d.getTime())?'-':d.toLocaleDateString('es-AR'); }
function toast(msg){ const t=document.getElementById('toast'); t.textContent=msg; t.classList.add('show'); setTimeout(()=>t.classList.remove('show'),2200); }
function setProgress(p){ const fill=document.getElementById('progress-fill'); const label=document.getElementById('progress-label'); const c=Math.max(0,Math.min(100,p)); fill.style.width=c+'%'; document.querySelector('.progress-bar').setAttribute('aria-valuenow',String(c)); label.textContent=c.toFixed(0)+'%'; }

const categoriasFallback=[
  {id:'alimentos', nombre:'Alimentos', color:'#8ab4f8'},
  {id:'transporte', nombre:'Transporte', color:'#34d399'},
  {id:'servicios', nombre:'Servicios', color:'#f472b6'},
  {id:'salud', nombre:'Salud', color:'#fbbf24'},
  {id:'educacion', nombre:'Educación', color:'#60a5fa'},
  {id:'ocio', nombre:'Ocio', color:'#a78bfa'},
  {id:'vivienda', nombre:'Vivienda', color:'#f87171'},
  {id:'otros', nombre:'Otros', color:'#22d3ee'}
];
const categoryColor = id => (categoriasFallback.find(c=>c.id===id)||{}).color || '#9aa3b2';

const state={config:{presupuesto:0,meta:0},gastos:[],filtros:{texto:'',orden:'fecha_desc'}};

document.addEventListener('DOMContentLoaded', async ()=>{
  state.config = storage.loadConfig();
  state.gastos = storage.loadGastos();

  document.getElementById('presupuesto').value = state.config.presupuesto || '';
  document.getElementById('meta').value = state.config.meta || '';

  await cargarCategorias();

  const fecha=document.getElementById('fecha'); if(fecha) fecha.valueAsDate=new Date();

  document.getElementById('config-form').addEventListener('submit', onSaveConfig);
  document.getElementById('gasto-form').addEventListener('submit', onSubmitGasto);
  document.getElementById('btn-cancelar-edicion').addEventListener('click', resetEdicion);
  document.getElementById('filtro').addEventListener('input', e=>{state.filtros.texto=e.target.value.toLowerCase(); renderLista();});
  document.getElementById('orden').addEventListener('change', e=>{state.filtros.orden=e.target.value; renderLista();});
  document.getElementById('btn-vaciar').addEventListener('click', onVaciar);
  document.getElementById('btn-exportar').addEventListener('click', onExportarCSV);

  renderResumen(); renderLista(); renderCategorias(); drawDonut();
});

async function cargarCategorias(){
  const select=document.getElementById('categoria'); select.innerHTML='';
  try{
    const resp=await fetch('data/categorias.json');
    if(!resp.ok) throw new Error('no ok');
    const cats=await resp.json();
    cats.forEach(c=>{ const opt=document.createElement('option'); opt.value=c.id; opt.textContent=c.nombre; select.append(opt); });
    if(select.options.length===0) throw new Error('sin opciones');
  }catch(_){
    categoriasFallback.forEach(c=>{ const opt=document.createElement('option'); opt.value=c.id; opt.textContent=c.nombre; select.append(opt); });
  }
}

function onSaveConfig(ev){
  ev.preventDefault();
  const presupuesto=parseFloat(document.getElementById('presupuesto').value);
  const meta=parseFloat(document.getElementById('meta').value);
  setError('err-presupuesto',''); setError('err-meta',''); let ok=true;
  if(isNaN(presupuesto)||presupuesto<0){ setError('err-presupuesto','Ingresá un presupuesto válido'); ok=false;}
  if(isNaN(meta)||meta<0){ setError('err-meta','Ingresá una meta válida'); ok=false;}
  if(!ok) return;
  state.config={presupuesto, meta}; storage.saveConfig(state.config);
  toast('Configuración guardada'); renderResumen(); drawDonut();
}

function onSubmitGasto(ev){
  ev.preventDefault();
  const editId=document.getElementById('gasto-id').value;
  if(editId){ onUpdateGasto(editId);} else { onAddGasto(); }
}

function onAddGasto(){
  const {desc,cat,monto,fecha}=leerCamposGasto();
  if(!validarCamposGasto({desc,cat,monto,fecha})) return;
  const id=String(Date.now()+Math.random());
  state.gastos.push({id, descripcion:desc, categoria:cat, monto, fecha});
  storage.saveGastos(state.gastos);
  limpiarFormGasto(); toast('Gasto agregado'); postCambios();
}

function onUpdateGasto(id){
  const {desc,cat,monto,fecha}=leerCamposGasto();
  if(!validarCamposGasto({desc,cat,monto,fecha})) return;
  const idx=state.gastos.findIndex(g=>g.id===id);
  if(idx!==-1){ state.gastos[idx]={...state.gastos[idx], descripcion:desc, categoria:cat, monto, fecha}; storage.saveGastos(state.gastos); toast('Gasto actualizado'); }
  resetEdicion(); postCambios();
}

function onEdit(id){
  const g=state.gastos.find(x=>x.id===id); if(!g) return;
  document.getElementById('gasto-id').value=g.id;
  document.getElementById('descripcion').value=g.descripcion;
  document.getElementById('categoria').value=g.categoria;
  document.getElementById('monto').value=g.monto;
  document.getElementById('fecha').value=g.fecha;
  document.getElementById('btn-submit-gasto').textContent='Guardar cambios';
  document.getElementById('btn-cancelar-edicion').style.display='inline-block';
}

function resetEdicion(){
  document.getElementById('gasto-id').value='';
  document.getElementById('btn-submit-gasto').textContent='Agregar gasto';
  document.getElementById('btn-cancelar-edicion').style.display='none';
  const fecha=document.getElementById('fecha'); if(fecha) fecha.valueAsDate=new Date();
}

function onRemove(id){
  state.gastos=state.gastos.filter(g=>g.id!==id);
  storage.saveGastos(state.gastos); toast('Gasto eliminado'); postCambios();
}

function onVaciar(){
  if(state.gastos.length===0){ toast('No hay gastos para eliminar'); return;}
  state.gastos=[]; storage.saveGastos(state.gastos); toast('Se vaciaron los gastos'); postCambios();
}

function onExportarCSV(){
  if(state.gastos.length===0){ toast('No hay datos para exportar'); return; }
  const header=['id','descripcion','categoria','monto','fecha'];
  const rows=state.gastos.map(g=>[g.id, csvEscape(g.descripcion), g.categoria, g.monto, g.fecha]);
  const csv=[header.join(','), ...rows.map(r=>r.join(','))].join('\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='gastos.csv'; document.body.appendChild(a); a.click(); a.remove();
}

function renderResumen(){
  const total=state.gastos.reduce((acc,g)=>acc+Number(g.monto||0),0);
  const saldo=(Number(state.config.presupuesto)||0)-total;
  const avance=calcAvance(saldo,state.config.meta);
  document.getElementById('sum-presupuesto').textContent=fmtMoney(Number(state.config.presupuesto)||0);
  document.getElementById('sum-gastos').textContent=fmtMoney(total);
  document.getElementById('sum-saldo').textContent=fmtMoney(saldo);
  setProgress(avance);
}

function renderLista(){
  const ul=document.getElementById('lista-gastos'); const vacio=document.getElementById('sin-gastos'); ul.innerHTML='';
  const filtrados=state.gastos.filter(g=>(g.descripcion||'').toLowerCase().includes(state.filtros.texto)).sort((a,b)=>sortBy(a,b,state.filtros.orden));
  if(filtrados.length===0){ vacio.style.display='block'; return; } vacio.style.display='none';
  for(const g of filtrados){
    const li=document.createElement('li'); li.className='list-item';
    li.innerHTML=`<span>${g.descripcion}</span><span class="muted">${capitalize(g.categoria)}</span><span class="mono">${fmtMoney(Number(g.monto)||0)}</span><span class="muted mono">${fmtDate(g.fecha)}</span><span class="btns"><button class="btn outline" data-edit="${g.id}">Editar</button><button class="btn danger outline" data-id="${g.id}">Eliminar</button></span>`;
    ul.append(li);
  }
  ul.querySelectorAll('button[data-id]').forEach(b=>b.addEventListener('click',e=>onRemove(e.currentTarget.getAttribute('data-id'))));
  ul.querySelectorAll('button[data-edit]').forEach(b=>b.addEventListener('click',e=>onEdit(e.currentTarget.getAttribute('data-edit'))));
}

function renderCategorias(){
  const ul=document.getElementById('cat-resumen'); ul.innerHTML='';
  const map=new Map(); for(const g of state.gastos){ map.set(g.categoria,(map.get(g.categoria)||0)+Number(g.monto||0)); }
  const arr=[...map.entries()].sort((a,b)=>b[1]-a[1]);
  if(arr.length===0){ const li=document.createElement('li'); li.textContent='Sin datos aún'; ul.append(li); return; }
  for(const [cat,total] of arr){
    const li=document.createElement('li');
    li.innerHTML=`<span><span class="legend-dot" style="background:${categoryColor(cat)}"></span><span class="badge-name">${capitalize(cat)}</span></span><span class="badge-amount">${fmtMoney(total)}</span>`;
    ul.append(li);
  }
}

function drawDonut(){
  const cnv=document.getElementById('donut'); if(!cnv) return; const ctx=cnv.getContext('2d'); const W=cnv.width,H=cnv.height;
  ctx.clearRect(0,0,W,H); const cx=W/2, cy=H/2, r=Math.min(W,H)/2-10; ctx.lineWidth=28;
  // fondo
  ctx.strokeStyle='#26304a'; ctx.beginPath(); ctx.arc(cx,cy,r,0,Math.PI*2); ctx.stroke();
  // totales por categoría
  const totals=new Map(); let grand=0;
  for(const g of state.gastos){ const v=Number(g.monto||0); if(v>0){ totals.set(g.categoria,(totals.get(g.categoria)||0)+v); grand+=v; } }
  if(grand<=0) return;
  let start=-Math.PI/2;
  for(const [cat,val] of totals.entries()){
    const frac=val/grand, end=start+frac*Math.PI*2;
    ctx.strokeStyle=categoryColor(cat); ctx.beginPath(); ctx.arc(cx,cy,r,start,end); ctx.stroke(); start=end;
  }
  // agujero
  ctx.globalCompositeOperation='destination-out'; ctx.beginPath(); ctx.arc(cx,cy,r-14,0,Math.PI*2); ctx.fill(); ctx.globalCompositeOperation='source-over';
  // etiqueta central
  ctx.fillStyle='#e6e8f0'; ctx.font='600 16px system-ui, Segoe UI, Roboto'; ctx.textAlign='center';
  ctx.fillText('Total gastos', cx, cy-6); ctx.font='700 18px system-ui, Segoe UI, Roboto'; ctx.fillText(fmtMoney(grand), cx, cy+16);
}

// helpers
function leerCamposGasto(){ return { desc:document.getElementById('descripcion').value.trim(), cat:document.getElementById('categoria').value, monto:parseFloat(document.getElementById('monto').value), fecha:document.getElementById('fecha').value }; }
function validarCamposGasto({desc,cat,monto,fecha}){ ['err-desc','err-cat','err-monto','err-fecha'].forEach(id=>setError(id,'')); let ok=true; if(!desc){setError('err-desc','Ingresá una descripción');ok=false;} if(!cat){setError('err-cat','Seleccioná una categoría');ok=false;} if(isNaN(monto)||monto<=0){setError('err-monto','Ingresá un monto válido');ok=false;} if(!fecha){setError('err-fecha','Seleccioná una fecha');ok=false;} return ok; }
function limpiarFormGasto(){ document.getElementById('descripcion').value=''; document.getElementById('monto').value=''; const fecha=document.getElementById('fecha'); if(fecha) fecha.valueAsDate=new Date(); }
function setError(id,msg){ const el=document.getElementById(id); if(el) el.textContent=msg||''; }
function calcAvance(saldo,meta){ const m=Number(meta)||0; if(m<=0) return 0; const s=Math.max(0,Number(saldo)||0); return Math.min(100,(s/m)*100); }
function sortBy(a,b,o){ switch(o){ case 'fecha_asc': return a.fecha.localeCompare(b.fecha); case 'monto_desc': return b.monto-a.monto; case 'monto_asc': return a.monto-b.monto; default: return b.fecha.localeCompare(a.fecha);} }
function capitalize(s){ s=String(s||''); return s.charAt(0).toUpperCase()+s.slice(1); }
function postCambios(){ renderResumen(); renderLista(); renderCategorias(); drawDonut(); }
function csvEscape(s){ const str=String(s??''); return /[",\n]/.test(str)?'"'+str.replace(/"/g,'""')+'"':str; }
