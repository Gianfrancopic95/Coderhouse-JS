// Entregable 1 - Simulador de Ahorro
// En este archivo uso variables, constantes, arrays, funciones, condicionales y ciclos.
// La app habla con el/la usuario/a por prompt, confirm y alert, y muestra resultados en la consola.

// ----- Variables y constantes -----
const APP_NAME = "Simulador de Ahorro";
let usuario = prompt("¡Hola! ¿Cómo te llamás?");
if (!usuario) usuario = "Sin nombre";

// Array para ir guardando los gastos como objetos {categoria, monto}
let gastos = [];

// ----- Funciones -----

// Valida que el número sea un valor real y mayor/igual a 0
function pedirNumero(mensaje) {
  let valor = prompt(mensaje);
  while (valor === null || valor.trim() === "" || isNaN(Number(valor)) || Number(valor) < 0) {
    alert("Por favor ingresá un número válido (0 o más).");
    valor = prompt(mensaje);
  }
  return Number(valor);
}

// Pide gastos al usuario. Devuelve un array con objetos {categoria, monto}
function pedirGastos() {
  let continuar = true;
  while (continuar) {
    let categoria = prompt("Ingresá la categoría del gasto (transporte, comida, ocio):");
    if (!categoria) categoria = "Sin categoría";
    const monto = pedirNumero("¿Cuánto fue el gasto?");
    gastos.push({ categoria: categoria.trim(), monto });
    continuar = confirm("¿Querés cargar otro gasto?");
  }
  return gastos;
}

// Suma todos los montos del array de gastos (uso for para el criterio de ciclo)
function calcularTotal(lista) {
  let total = 0;
  for (let i = 0; i < lista.length; i++) total += lista[i].monto;
  return total;
}

// Devuelve un string con formato moneda simple 
function formatearMoneda(valor) {
  return "$ " + valor.toFixed(2);
}

// Genera un resumen y lo muestra por consola y alert
function generarResumen(nombre, lista, presupuesto, meta) {
  if (lista.length === 0) {
    alert("No cargaste gastos.");
    return;
  }
  const totalGastos = calcularTotal(lista);
  const promedio = totalGastos / lista.length;
  let gastoMax = lista[0];
  for (let i = 1; i < lista.length; i++) if (lista[i].monto > gastoMax.monto) gastoMax = lista[i];
  const ahorroReal = presupuesto - totalGastos;
  let mensajeMeta = (ahorroReal >= meta)
    ? "¡Bien! Alcanzás la meta de ahorro."
    : "No alcanzás la meta. Podrías ajustar gastos.";
  console.log("===== Resumen =====");
  console.log("Usuario/a:", nombre);
  console.log("Presupuesto:", formatearMoneda(presupuesto));
  console.log("Total de gastos:", formatearMoneda(totalGastos));
  console.log("Ahorro real:", formatearMoneda(ahorroReal));
  console.log("Meta:", formatearMoneda(meta));
  console.log(mensajeMeta);
  alert("Presupuesto: " + formatearMoneda(presupuesto) +
        "\nTotal gastos: " + formatearMoneda(totalGastos) +
        "\nAhorro real: " + formatearMoneda(ahorroReal) +
        "\nMeta: " + formatearMoneda(meta) +
        "\n\n" + mensajeMeta);
}

alert("Bienvenido/a al " + APP_NAME + ", " + usuario + "!");
if (confirm("¿Querés empezar el simulador ahora?")) {
  const presupuesto = pedirNumero("Ingresá tu presupuesto inicial:");
  const meta = pedirNumero("Ingresá tu meta de ahorro:");
  pedirGastos();
  generarResumen(usuario, gastos, presupuesto, meta);
} else {
  alert("Podés recargar la página cuando quieras para empezar.");
}
